package com.raffael.teclaura

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF090A12)
private val SurfaceGlass = Color(0xFF1B1B2B)
private val Accent = Color(0xFFAA82FF)
private val Cyan = Color(0xFF70C8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TeclauraHome(
            onEnable = { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) },
            onChoose = { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        ) }
    }
}

@Composable
private fun TeclauraHome(onEnable: () -> Unit, onChoose: () -> Unit) {
    var selected by remember { mutableStateOf("Início") }
    var glass by remember { mutableStateOf(true) }
    var rgb by remember { mutableStateOf(false) }
    var transparency by remember { mutableFloatStateOf(0.72f) }
    val tabs = listOf("Início", "Aparência", "Teclado", "IA", "Ajustes")

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Background, surface = SurfaceGlass
    )) {
        Scaffold(
            containerColor = Background,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF11121D)) {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            icon = { Text(
                                when(tab) {
                                    "Início" -> "⌂"
                                    "Aparência" -> "◈"
                                    "Teclado" -> "⌨"
                                    "IA" -> "✦"
                                    else -> "⚙"
                                }, fontSize = 19.sp
                            ) },
                            label = { Text(tab, fontSize = 10.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(22.dp))
                Text("TECLAURA-IA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Text("Criado por @raffael.sz", color = Accent, fontSize = 12.sp)
                Spacer(Modifier.height(20.dp))

                when(selected) {
                    "Início" -> {
                        GlassPanel {
                            Text("Seu teclado. Seu estilo.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text("Uma experiência de digitação personalizável com ferramentas inteligentes.", color = Color.LightGray)
                            Spacer(Modifier.height(18.dp))
                            KeyboardMock()
                        }
                        Spacer(Modifier.height(14.dp))
                        ActionPanel("Ativar Teclaura-IA", "Abra as configurações de teclado do Android", onEnable)
                        ActionPanel("Escolher teclado", "Selecione Teclaura-IA como método de entrada", onChoose)
                    }
                    "Aparência" -> {
                        SectionTitle("Aparência", "Personalize o visual do teclado")
                        GlassPanel {
                            ToggleRow("Liquid Glass", "Efeito translúcido e aparência de vidro", glass) { glass = it }
                            HorizontalDivider(color = Color.White.copy(alpha = .08f))
                            Text("Transparência ${(transparency * 100).toInt()}%", color = Color.White)
                            Slider(value = transparency, onValueChange = { transparency = it })
                            ToggleRow("Modo RGB", "Ciclo de cores (configuração visual)", rgb) { rgb = it }
                            ActionPanel("Papel de parede", "Seleção de imagem será implementada na próxima etapa") {}
                        }
                    }
                    "Teclado" -> {
                        SectionTitle("Teclado", "Prévia do layout")
                        GlassPanel { KeyboardMock() }
                        Spacer(Modifier.height(12.dp))
                        ActionPanel("Ativar teclado", "Configure o Teclaura-IA no Android", onEnable)
                    }
                    "IA" -> {
                        SectionTitle("Inteligência Artificial", "Ferramentas planejadas para o teclado")
                        ActionPanel("Traduzir", "Traduzir o texto para outro idioma") {}
                        ActionPanel("Corrigir texto", "Ortografia, pontuação e gramática") {}
                        ActionPanel("Responder", "Escolha: formal, informal, engraçado, carinhoso ou direto") {}
                        ActionPanel("ChatGPT e Gemini", "Acesso online; integração será desenvolvida") {}
                        ActionPanel("IA local", "Modelos offline opcionais") {}
                        Text("As ações de IA ainda não estão conectadas nesta versão de protótipo.", color = Color(0xFFFFD18A), fontSize = 12.sp)
                    }
                    else -> {
                        SectionTitle("Ajustes", "Preferências e informações")
                        ActionPanel("Idioma", "Português (Brasil)") {}
                        ActionPanel("Privacidade", "Configurações de privacidade") {}
                        ActionPanel("Sobre", "Teclaura-IA 0.1.0 • @raffael.sz") {}
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
    Text(subtitle, color = Color.LightGray, fontSize = 13.sp)
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(Color(0xFF29243E), SurfaceGlass.copy(alpha = .94f), Color(0xFF142333))),
                RoundedCornerShape(24.dp)
            ).padding(17.dp),
        content = content
    )
}

@Composable
private fun ActionPanel(title: String, subtitle: String, action: () -> Unit) {
    GlassPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Spacer(Modifier.height(3.dp))
                Text(subtitle, color = Color.LightGray, fontSize = 12.sp)
            }
            Text("›", color = Accent, fontSize = 28.sp)
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = action) { Text("Abrir", color = Cyan) }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Color.LightGray, fontSize = 11.sp)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun KeyboardMock() {
    Column(
        Modifier.fillMaxWidth()
            .background(Color(0xCC252438), RoundedCornerShape(18.dp))
            .padding(9.dp)
    ) {
        Text("✦   Traduzir     Corrigir     Responder", color = Color.White, fontSize = 11.sp)
        Spacer(Modifier.height(9.dp))
        listOf("qwertyuiop", "asdfghjkl", "⇧zxcvbnm⌫").forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { key ->
                    Box(
                        Modifier.weight(1f).padding(vertical = 3.dp)
                            .background(Color(0xFF55546A), RoundedCornerShape(7.dp))
                            .padding(vertical = 11.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(key.toString(), color = Color.White, fontSize = 12.sp) }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("?123", "☺", "Português", "↵").forEach { key ->
                Box(
                    Modifier.weight(if(key == "Português") 3f else 1f)
                        .background(Color(0xFF55546A), RoundedCornerShape(7.dp))
                        .padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) { Text(key, color = Color.White, fontSize = 11.sp) }
            }
        }
    }
}
