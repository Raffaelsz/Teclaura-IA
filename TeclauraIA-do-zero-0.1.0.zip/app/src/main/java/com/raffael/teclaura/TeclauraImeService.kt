package com.raffael.teclaura

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class TeclauraImeService : InputMethodService() {
    private val rows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 10, 6, 10)
            setBackgroundColor(Color.rgb(25, 24, 40))
        }

        val tools = TextView(this).apply {
            text = "✦   Traduzir       Corrigir       Responder"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(4, 12, 4, 16)
        }
        root.addView(tools, LinearLayout.LayoutParams(-1, -2))

        rows.forEach { row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            row.forEach { letter ->
                line.addView(makeKey(letter.toString()) {
                    currentInputConnection?.commitText(letter.toString(), 1)
                }, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(2), dp(3), dp(2), dp(3))
                })
            }
            root.addView(line)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        listOf("?123", "⌫", "ESPAÇO", "↵").forEach { label ->
            val weight = if (label == "ESPAÇO") 2.4f else 1f
            bottom.addView(makeKey(label) {
                when(label) {
                    "⌫" -> currentInputConnection?.deleteSurroundingText(1, 0)
                    "ESPAÇO" -> currentInputConnection?.commitText(" ", 1)
                    "↵" -> currentInputConnection?.commitText("\n", 1)
                    else -> currentInputConnection?.commitText(label, 1)
                }
            }, LinearLayout.LayoutParams(0, dp(48), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            })
        }
        root.addView(bottom)
        return root
    }

    private fun makeKey(label: String, action: () -> Unit): View {
        return Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT
            isAllCaps = false
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(77, 73, 99)))
            setOnClickListener { action() }
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            setPadding(0, 0, 0, 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
