# Teclaura-IA

Projeto Android independente em Kotlin.

Criador: @raffael.sz

## Compilar APK
O workflow GitHub Actions em `.github/workflows/android.yml` compila o APK debug ao enviar alterações para `main` ou ao executar manualmente.

O artefato gerado chama-se `Teclaura-IA-debug`.

## Estado desta versão
Protótipo inicial: interface, navegação e teclado Android básico. Os controles de aparência e as opções de IA ainda são demonstrativos e serão implementados em etapas posteriores.
